<?php
/* @var $this yii\web\View */
$this->title = 'e-Warung POS';
?>
    <div class="site-index">
        <div class="jumbotron">
            <h1>Selamat Datang!</h1>

            <p class="lead">Aplikasi e-Warung berbasis Web.</p>
        </div>
        <div class="body-content">
        </div>
    </div>
<?php
shell_exec('D:/CashDrawer/run.exe');